'use strict';

var fs = require('fs');

// get marked edges
var edges = fs.readFileSync('edges.tsv').toString('utf8').split('\n');
var edgeMap = {};
edges.forEach(function(edge){
	edgeMap[edge] = true;
});

// read all vecs
var geneVecs = {};
var deseaseVecs = {};
var vecLen = {};
['gene_vec_filtered', 'desease_vec_filtered'].forEach(function(inDir){
	fs.readdirSync(inDir).forEach(function(gd){
		var data = JSON.parse(fs.readFileSync(inDir + '/' + gd).toString('utf8'));
		if(!Object.keys(data).length) return;
		if(inDir[0] === 'g') geneVecs[gd] = data;
		else deseaseVecs[gd] = data;
		var vlen = 0;
		for(var k in data) {
			vlen += data[k] * data[k];
		}
		vecLen[gd] = Math.sqrt(vlen);
	});
});

// cal cos for two vecs
var calCos = function(v1, v2, l1, l2){
	var c = 0;
	for(var k in v1) {
		if(!v2[k]) continue;
		c += v1[k] * v2[k];
	}
	return c / (l1*l2);
};

// gene-desease
var gdMatch = [];
for(var g in geneVecs) {
	console.log('Processing: ' + g);
	for(var d in deseaseVecs) {
		var cos = calCos(geneVecs[g], deseaseVecs[d], vecLen[g], vecLen[d]);
		gdMatch.push({
			g: g,
			d: d,
			cos: cos
		});
	}
}
console.log('Sorting...');
gdMatch.sort(function(a, b){
	return b.cos - a.cos;
});

var str = '';
gdMatch.forEach(function(m){
	var marked = false;
	if(edgeMap[m.g + '\t' + m.d]) marked = true;
	str += m.g + '\t' + m.d + '\t' + m.cos + '\t' + marked + '\n';
});
fs.writeFileSync('gd_match.tsv', str);

