'use strict';

var fs = require('fs');

var blacklist = JSON.parse(fs.readFileSync('blacklist.json', {encoding: 'utf8'}));

['gene_docs_arr', 'desease_docs_arr'].forEach(function(inDir){
	var outDir = inDir.slice(0, inDir.indexOf('_')) + '_vec';
	try{ fs.mkdirSync(outDir) } catch(e){}
	fs.readdirSync(inDir).forEach(function(gd){
		console.log('Processing: ' + outDir + ' "' + gd + '"');
		var gdVec = {};
		fs.readdirSync(inDir + '/' + gd).forEach(function(file){
			// ignore files in blacklist for desease
			if(inDir[0] === 'd' && blacklist[file]) return;
			var doc = JSON.parse(fs.readFileSync(inDir + '/' + gd + '/' + file, {encoding: 'utf8'}));
			// find where the gd is
			var pos = '';
			if(doc.mesh.indexOf(gd) >= 0) {
				pos = 'mesh';
			} else if(doc.title.indexOf(gd) >= 0) {
				pos = 'title';
			} else if(Array.prototype.concat.apply([], doc.abstract).indexOf(gd) >= 0) {
				pos = 'abstract';
			} else {
				return;
			}
			var weights = WEIGHTS[pos];
			// get vector
			var vec = {};
			var hasTerm = {};
			doc.title.forEach(function(term){
				if(term === gd) return;
				if(hasTerm[term]) return;
				if(vec[term]) {
					vec[term] += weights.title;
				} else {
					vec[term] = weights.title;
				}
				hasTerm[term] = 1;
			});
			doc.abstract.forEach(function(sentence){
				var weight = weights.abstractAll;
				if(sentence.indexOf(gd) >= 0) {
					weight = weights.abstractNear;
				}
				var hasTerm = {};
				sentence.forEach(function(term){
					if(term === gd) return;
					if(hasTerm[term]) return;
					if(vec[term]) {
						vec[term] += weight;
					} else {
						vec[term] = weight;
					}
					hasTerm[term] = 1;
				});
			});
			var hasTerm = {};
			doc.mesh.forEach(function(term){
				if(term === gd) return;
				if(hasTerm[term]) return;
				if(vec[term]) {
					vec[term] += weights.mesh;
				} else {
					vec[term] = weights.mesh;
				}
				hasTerm[term] = 1;
			});
			for(var term in vec) {
				if(gdVec[term]) {
					gdVec[term] += vec[term];
				} else {
					gdVec[term] = vec[term];
				}
			}
		});
		fs.writeFileSync(outDir + '/' + gd, JSON.stringify(gdVec, null, '\t'));
	});
});

