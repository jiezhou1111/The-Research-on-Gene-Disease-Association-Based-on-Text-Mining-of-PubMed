'use strict';

var fs = require('fs');

var termPathsMap = JSON.parse(fs.readFileSync('terms_map.json', {encoding: 'utf8'}));
var termLength = JSON.parse(fs.readFileSync('segment_length.json', {encoding: 'utf8'}));

// calculating idf
var idf = {};
['gene_vec', 'desease_vec'].forEach(function(inDir){
	fs.readdirSync(inDir).forEach(function(gd){
		var map = JSON.parse(fs.readFileSync(inDir + '/' + gd, {encoding: 'utf8'}));
		
		// normalize
		var sum = 0;
		var sum2 = 0;
		for(var term in map) {
			sum += map[term];
			sum2 += map[term] * map[term];
		}
		if(DOC_REDUCE_METHOD === 'sqrt') {
			var logSum = 1 / Math.sqrt(sum2);
		} else if(DOC_REDUCE_METHOD === 'n') {
			var logSum = 1 / sum;
		} else if(DOC_REDUCE_METHOD === '1') {
			var logSum = 1;
		} else {
			var logSum = 1 / Math.log(sum + 1);
		}
		
		for(var term in map) {
			if(idf[term]) {
				idf[term] += map[term] * logSum;
			} else {
				idf[term] = map[term] * logSum;
			}
		}
	});
});
for(var term in idf) {
	var i = 0;
	if(IDF_METHOD === 'sqrt') i = 1 / Math.sqrt(idf[term]);
	else if(IDF_METHOD === '1') i = 1 / idf[term];
	else i = 1 / Math.log(idf[term] + 1);
	idf[term] = (MESH_LENGTH_PENALTY[termLength[term]] || 1) * i;
}

// remove unaccepted MeSH types
['gene_vec', 'desease_vec'].forEach(function(inDir){
	var outDir = inDir + '_filtered';
	try{ fs.mkdirSync(outDir) } catch(e){}
	fs.readdirSync(inDir).forEach(function(gd){
		var map = JSON.parse(fs.readFileSync(inDir + '/' + gd, {encoding: 'utf8'}));
		var newMap = {};
		
		// normalize
		var sum = 0;
		var sum2 = 0;
		for(var term in map) {
			sum += map[term];
			sum2 += map[term] * map[term];
		}
		if(DOC_REDUCE_METHOD === 'sqrt') {
			var logSum = 1 / Math.sqrt(sum2);
		} else if(DOC_REDUCE_METHOD === 'n') {
			var logSum = 1 / sum;
		} else if(DOC_REDUCE_METHOD === '1') {
			var logSum = 1;
		} else {
			var logSum = 1 / Math.log(sum + 1);
		}
		
		for(var term in map) {
			var paths = termPathsMap[term];
			if(!paths) continue;
			for(var i=0; i<paths.length; i++) {
				var path = paths[i];
				if(!ACCEPT_MESH_TYPES.length || ACCEPT_MESH_TYPES.indexOf(path.charAt(0)) >= 0) break;
			}
			if(i < paths.length) newMap[term] = map[term] * idf[term] * logSum;
		}
		fs.writeFileSync(outDir + '/' + gd, JSON.stringify(newMap, null, '\t'));
	});
});

