'use strict';

var fs = require('fs');

// read tsv
var rows = [];
fs.readFileSync('gd_match.tsv', {encoding: 'utf8'}).split('\n').forEach(function(line){
	if(!line) return;
	var cols = line.split('\t');
	rows.push(cols);
});

// stat trues
var trueCount = 0;
rows.forEach(function(row){
	if(row[3] === 'true') trueCount++;
});

// stat P(x)
var stat = new Array(100);
var curRow = 0;
var curTrueRow = 0;
for(var percent = 99; percent >= 0; percent--) {
	var rate = percent / 100;
	while( rows[curRow] && Number(rows[curRow][2]) >= rate ) {
		if(rows[curRow][3] === 'true') curTrueRow++;
		curRow++;
	}
	stat[percent] = [
		percent + '%',
		curRow,
		curTrueRow,
	].join('\t');
}
fs.writeFileSync('gd_stat_' + RESULT_CLASS + '.tsv', stat.join('\n') + '\n');

// stat P(R)
var statPr = new Array(100);
var curTrueRowMax = curTrueRow;
curRow = 0;
curTrueRow = 0;
for(var percent = 0; percent < 100; percent++) {
	var rate = percent / 100;
	while( curTrueRow < curTrueRowMax * rate ) {
		if(rows[curRow++][3] === 'true') curTrueRow++;
	}
	statPr[percent] = [
		percent + '%',
		curRow,
		curTrueRow,
	].join('\t');
}
fs.writeFileSync('gd_stat_pr_' + RESULT_CLASS + '.tsv', statPr.join('\n') + '\n');

