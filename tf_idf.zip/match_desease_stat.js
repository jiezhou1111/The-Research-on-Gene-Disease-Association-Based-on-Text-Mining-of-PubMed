'use strict';

var fs = require('fs');

// read tsv and split per desease
var geneRows = {};
fs.readFileSync('gd_match.tsv', {encoding: 'utf8'}).split('\n').forEach(function(line){
	if(!line) return;
	var cols = line.split('\t');
	var d = cols[1];
	if(!geneRows[d]) geneRows[d] = [];
	geneRows[d].push(cols);
});

// stat
var gc = [];
var dc = 0;
for(var k in geneRows) {
	dc++;
	var rows = geneRows[k];
	for(var i=0; i<rows.length; i++) {
		if(rows[i][3] === 'true') break;
	}
	gc.push(i);
}
var stat = new Array(100);
for(var i=0; i<stat.length; i++) {
	stat[i] = 0;
}
gc.forEach(function(c){
	if(c < 100) stat[c]++;
});
for(var i=0; i<stat.length; i++) {
	stat[i] /= dc;
	if(i) stat[i] += stat[i-1];
}

fs.writeFileSync('gd_stat_og_' + RESULT_CLASS + '.tsv', stat.join('\n') + '\n');
