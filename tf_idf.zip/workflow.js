// arguments

global.WEIGHTS = {
	mesh: {
		title: 3,
		abstractNear: 3,
		abstractAll: 2,
		mesh: 3
	},
	title: {
		title: 2,
		abstractNear: 2,
		abstractAll: 1,
		mesh: 3
	},
	abstract: {
		title: 1,
		abstractNear: 2,
		abstractAll: 1,
		mesh: 2
	}
};

global.DOC_REDUCE_METHOD = 'log';

global.ACCEPT_MESH_TYPES = [];

global.MESH_LENGTH_PENALTY = [0, 1/16, 1/8, 1/4, 1/2];

global.IDF_METHOD = 'sqrt';

global.RESULT_CLASS = 'MESHANY';

// processes

var step = Number(process.argv[2]) || 0;
if(step <= 0) require('./combine_docs.js');
if(step <= 1) require('./vec_filter.js');
if(step <= 2) require('./cross_match.js');
if(step <= 3) require('./match_stat.js');
//if(step <= 4) require('./match_desease_stat.js');

