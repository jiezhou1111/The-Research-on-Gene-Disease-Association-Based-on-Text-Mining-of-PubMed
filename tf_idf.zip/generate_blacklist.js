'use strict';

var fs = require('fs');

// get doc map of all genes
var docs = {};
var countDistinct = 0;
var count = 0;
fs.readdirSync('gene_docs_arr').forEach(function(dir){
	fs.readdirSync('gene_docs_arr/' + dir).forEach(function(id){
		if(docs[id]) docs[id]++;
		else {
			countDistinct++;
			docs[id] = 1;
		}
		count++;
	});
});

console.log('Altogether ' + count + ' docs for genes.');
console.log(countDistinct + ' distinct docs logged.');

fs.writeFileSync('blacklist.json', JSON.stringify(docs, null, '\t'));

